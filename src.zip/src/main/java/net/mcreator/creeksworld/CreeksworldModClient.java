package net.mcreator.creeksworld;

import net.mcreator.creeksworld.init.CreeksworldModModels;
import net.mcreator.creeksworld.init.CreeksworldModEntityRenderers;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

@Environment(EnvType.CLIENT)
public class CreeksworldModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		CreeksworldModModels.clientLoad();
		CreeksworldModEntityRenderers.clientLoad();
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}